#include "Observer.h"

//CONSTRUCTORS
/**Default constructor.*/
Observer::Observer() {}

//DESTRUCTORS
/**Observer destructor.*/
Observer::~Observer() {}
